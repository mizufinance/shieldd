//! Benchmark: `hex()` encoding.

use criterion::{Criterion, criterion_group};
use rand::{Rng, SeedableRng, rngs::StdRng};
use std::hint::black_box;

fn bench_encode(c: &mut Criterion) {
    for size in [16usize, 32, 64, 256, 1024, 16 * 1024] {
        let mut rng = StdRng::seed_from_u64(size as u64);
        let mut buf = vec![0u8; size];
        rng.fill_bytes(&mut buf);

        c.bench_function(&format!("{}/size={size}", module_path!()), |b| {
            b.iter(|| black_box(commonware_formatting::hex(black_box(&buf))));
        });
    }
}

criterion_group! {
    name = benches;
    config = Criterion::default().sample_size(50);
    targets = bench_encode,
}
