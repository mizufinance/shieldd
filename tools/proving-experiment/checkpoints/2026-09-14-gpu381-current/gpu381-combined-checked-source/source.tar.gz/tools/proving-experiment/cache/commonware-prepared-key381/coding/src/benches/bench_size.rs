use commonware_codec::EncodeSize as _;
use commonware_coding::{Config, PhasedAsScheme, ReedSolomon, Scheme, Zoda};
use commonware_cryptography::Sha256;
use commonware_parallel::Sequential;
use commonware_utils::NZU16;
use rand::{Rng as _, SeedableRng as _};
use rand_chacha::ChaCha8Rng;

const STRATEGY: Sequential = Sequential;

fn bench_size<S: Scheme>(name: &str) {
    let mut rng = ChaCha8Rng::seed_from_u64(0);
    let cases = [8, 12, 16, 19, 20, 22, 23, 24].map(|i| 2usize.pow(i));

    for data_length in cases.into_iter() {
        for chunks in [10u16, 25, 50, 100, 250] {
            let min = chunks / 3;
            let config = Config {
                minimum_shards: NZU16!(min),
                extra_shards: NZU16!(chunks - min),
            };

            let data = {
                let mut data = vec![0u8; data_length];
                rng.fill_bytes(&mut data);
                data
            };

            let (_, shards) = S::encode(&config, data.as_slice(), &STRATEGY).unwrap();
            let shard = &shards[0];
            println!(
                "{} (shard)/msg_len={} chunks={}: {} B",
                name,
                data_length,
                chunks,
                shard.encode_size()
            );
            println!();
        }
    }
}

fn main() {
    bench_size::<ReedSolomon<Sha256>>("reed_solomon size");
    bench_size::<PhasedAsScheme<Zoda<Sha256>>>("zoda size");
}
