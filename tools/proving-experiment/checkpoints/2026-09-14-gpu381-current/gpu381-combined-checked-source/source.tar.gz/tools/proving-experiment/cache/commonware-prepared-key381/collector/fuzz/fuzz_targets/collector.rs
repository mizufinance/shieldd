#![no_main]

use arbitrary::Arbitrary;
use commonware_actor::{Feedback, Unreliable};
use commonware_codec::{
    Encode, EncodeSize, Error as CodecError, FixedSize, RangeCfg, Read, ReadExt, ReadRangeExt,
    Write,
};
use commonware_collector::{
    Handler, Monitor, Originator,
    p2p::{Config, Engine, Mailbox},
};
use commonware_cryptography::{
    Committable, Digestible, Hasher, Sha256, Signer,
    ed25519::{PrivateKey, PublicKey},
    sha256::Digest,
};
use commonware_p2p::{Blocker, CheckedSender, LimitedSender, Receiver, Recipients};
use commonware_runtime::{
    Buf, BufMut, Clock, IoBuf, IoBufMut, IoBufs, Runner, Supervisor as _, deterministic,
};
use commonware_utils::{
    TestRng,
    channel::{mpsc, oneshot},
};
use libfuzzer_sys::fuzz_target;
use rand::RngExt as _;
use std::{
    collections::HashMap,
    num::NonZeroUsize,
    time::{Duration, SystemTime},
};

const MAX_LEN: usize = 1_000_000;
const MAX_OPERATIONS: usize = 256;
const MIN_BUFFER_SIZE: u16 = 1;

#[derive(Debug, Arbitrary)]
enum RecipientsType {
    All,
    One,
    Some,
}

#[derive(Clone, Debug, PartialEq, Eq, Hash, Arbitrary)]
struct FuzzRequest {
    id: u64,
    data: Vec<u8>,
}

impl Write for FuzzRequest {
    fn write(&self, buf: &mut impl BufMut) {
        self.id.write(buf);
        self.data.write(buf);
    }
}

impl Read for FuzzRequest {
    type Cfg = RangeCfg<usize>;
    fn read_cfg(buf: &mut impl Buf, cfg: &Self::Cfg) -> Result<Self, CodecError> {
        let id = u64::read(buf)?;
        let data = Vec::read_range(buf, *cfg)?;
        Ok(Self { id, data })
    }
}

impl EncodeSize for FuzzRequest {
    fn encode_size(&self) -> usize {
        u64::SIZE + self.data.encode_size()
    }
}

impl Committable for FuzzRequest {
    type Commitment = Digest;
    fn commitment(&self) -> Self::Commitment {
        Sha256::hash(&[&self.id.encode()])
    }
}

impl Digestible for FuzzRequest {
    type Digest = Digest;
    fn digest(&self) -> Self::Digest {
        Sha256::hash(&[&self.encode()])
    }
}

#[derive(Clone, Debug, PartialEq, Eq, Hash, Arbitrary)]
struct FuzzResponse {
    id: u64,
    result: Vec<u8>,
}

impl Write for FuzzResponse {
    fn write(&self, buf: &mut impl BufMut) {
        self.id.write(buf);
        self.result.write(buf);
    }
}

impl Read for FuzzResponse {
    type Cfg = RangeCfg<usize>;
    fn read_cfg(buf: &mut impl Buf, cfg: &Self::Cfg) -> Result<Self, CodecError> {
        let id = u64::read(buf)?;
        let result = Vec::read_range(buf, *cfg)?;
        Ok(Self { id, result })
    }
}

impl EncodeSize for FuzzResponse {
    fn encode_size(&self) -> usize {
        u64::SIZE + self.result.encode_size()
    }
}

impl Committable for FuzzResponse {
    type Commitment = Digest;
    fn commitment(&self) -> Self::Commitment {
        Sha256::hash(&[&self.id.encode()])
    }
}

impl Digestible for FuzzResponse {
    type Digest = Digest;
    fn digest(&self) -> Self::Digest {
        Sha256::hash(&[&self.encode()])
    }
}

#[derive(Clone)]
struct FuzzHandler {
    respond: bool,
    response_map: HashMap<u64, FuzzResponse>,
}

impl FuzzHandler {
    fn new(respond: bool, mut rng: TestRng) -> Self {
        let mut response_map = HashMap::new();
        for _ in 0..rng.random_range(0..10) {
            let id = rng.random();
            let result_len = rng.random_range(0..100);
            let mut result = vec![0u8; result_len];
            rng.fill(&mut result[..]);
            response_map.insert(id, FuzzResponse { id, result });
        }
        Self {
            respond,
            response_map,
        }
    }
}

impl Handler for FuzzHandler {
    type PublicKey = PublicKey;
    type Request = FuzzRequest;
    type Response = FuzzResponse;

    fn process(
        &mut self,
        _origin: Self::PublicKey,
        request: Self::Request,
        response: oneshot::Sender<Self::Response>,
    ) {
        if self.respond {
            let resp = self
                .response_map
                .get(&request.id)
                .cloned()
                .unwrap_or_else(|| FuzzResponse {
                    id: request.id,
                    result: request.data.clone(),
                });
            let _ = response.send(resp);
        }
    }
}

#[derive(Clone)]
struct FuzzMonitor {
    collected_count: usize,
}

impl FuzzMonitor {
    fn new() -> Self {
        Self { collected_count: 0 }
    }
}

impl Monitor for FuzzMonitor {
    type PublicKey = PublicKey;
    type Response = FuzzResponse;

    fn collected(&mut self, _handler: Self::PublicKey, _response: Self::Response, _count: usize) {
        self.collected_count += 1;
    }
}

#[derive(Clone)]
struct FuzzBlocker;

impl Blocker for FuzzBlocker {
    type PublicKey = PublicKey;

    fn block(&mut self, _peer: Self::PublicKey) -> Feedback {
        Feedback::Ok
    }
}

#[derive(Debug, Clone)]
struct MockSender;

impl LimitedSender for MockSender {
    type PublicKey = PublicKey;
    type Checked<'a> = MockCheckedSender;

    fn check(
        &mut self,
        _recipients: Recipients<Self::PublicKey>,
    ) -> Result<Self::Checked<'_>, SystemTime> {
        Ok(MockCheckedSender)
    }
}

struct MockCheckedSender;

impl CheckedSender for MockCheckedSender {
    type PublicKey = PublicKey;

    fn recipients(&self) -> Vec<Self::PublicKey> {
        Vec::new()
    }

    fn send(self, _message: impl Into<IoBufs> + Send, _priority: bool) -> Unreliable<Feedback> {
        Unreliable::new(Feedback::Ok)
    }
}

#[derive(Debug)]
struct MockReceiver {
    rx: mpsc::UnboundedReceiver<(PublicKey, Result<FuzzRequest, CodecError>)>,
}

#[derive(Debug, thiserror::Error)]
#[error("mock receive error")]
struct MockRecvError;

impl Receiver for MockReceiver {
    type Error = MockRecvError;
    type PublicKey = PublicKey;

    async fn recv(&mut self) -> Result<(Self::PublicKey, IoBuf), Self::Error> {
        let (pk, msg) = self.rx.recv().await.ok_or(MockRecvError)?;
        match msg {
            Ok(req) => {
                let mut buf = IoBufMut::with_capacity(req.encode_size());
                req.write(&mut buf);
                Ok((pk, buf.freeze()))
            }
            Err(_) => Err(MockRecvError),
        }
    }
}

#[derive(Arbitrary, Debug)]
enum CollectorOperation {
    SendRequest {
        peer_idx: u8,
        request: FuzzRequest,
        recipients_type: RecipientsType,
    },
    CancelRequest {
        request_id: u64,
    },
    ProcessHandler {
        peer_idx: u8,
        origin_idx: u8,
        request: FuzzRequest,
        should_respond: bool,
    },
    MonitorCollected {
        peer_idx: u8,
        response: FuzzResponse,
        count: usize,
    },
    CreateEngine {
        peer_idx: u8,
        mailbox_size: u16,
        priority_request: bool,
        priority_response: bool,
    },
}

#[derive(Debug)]
struct FuzzInput {
    seed: u64,
    operations: Vec<CollectorOperation>,
}

impl<'a> Arbitrary<'a> for FuzzInput {
    fn arbitrary(u: &mut arbitrary::Unstructured<'a>) -> arbitrary::Result<Self> {
        let seed = u.arbitrary()?;
        let num_ops = u.int_in_range(1..=MAX_OPERATIONS)?;
        let operations = (0..num_ops)
            .map(|_| CollectorOperation::arbitrary(u))
            .collect::<Result<Vec<_>, _>>()?;
        Ok(FuzzInput { seed, operations })
    }
}

fn fuzz(input: FuzzInput) {
    let mut rng = TestRng::new(input.seed);

    let executor = deterministic::Runner::seeded(input.seed);
    executor.start(|context| async move {
        let mut peers: Vec<PrivateKey> = Vec::new();
        let mut mailboxes: HashMap<usize, Mailbox<PublicKey, FuzzRequest>> = HashMap::new();
        let mut handlers: HashMap<usize, FuzzHandler> = HashMap::new();
        let mut monitors: HashMap<usize, FuzzMonitor> = HashMap::new();
        let mut restarts = 0usize;

        for i in 2..5 {
            let seed = rng.random();
            peers.push(PrivateKey::from_seed(seed));
            handlers.insert(i, FuzzHandler::new(rng.random(), TestRng::new(seed)));
            monitors.insert(i, FuzzMonitor::new());
        }
        assert!(!peers.is_empty(), "no peers");

        for op in input.operations {
            match op {
                CollectorOperation::SendRequest {
                    peer_idx,
                    request,
                    recipients_type,
                } => {
                    let idx = (peer_idx as usize) % peers.len();
                    if let Some(mailbox) = mailboxes.get_mut(&idx) {
                        let recipients = match recipients_type {
                            RecipientsType::All => Recipients::All,
                            RecipientsType::One => {
                                let target_idx = rng.random_range(0..peers.len());
                                Recipients::One(peers[target_idx].public_key())
                            }
                            RecipientsType::Some => {
                                let mut selected = vec![];
                                for (i, peer) in peers.iter().enumerate() {
                                    if i != idx && rng.random_bool(0.5) {
                                        selected.push(peer.public_key());
                                    }
                                }
                                Recipients::Some(selected)
                            }
                        };
                        let _ = mailbox.send(recipients, request);
                    }
                }

                CollectorOperation::CancelRequest { request_id } => {
                    let request = FuzzRequest {
                        id: request_id,
                        data: vec![],
                    };
                    let commitment = request.commitment();

                    for mailbox in mailboxes.values_mut() {
                        mailbox.cancel(commitment);
                    }
                }

                CollectorOperation::ProcessHandler {
                    peer_idx,
                    origin_idx,
                    request,
                    should_respond,
                } => {
                    let handler_idx = (peer_idx as usize) % peers.len();
                    let origin_idx = (origin_idx as usize) % peers.len();

                    if let Some(handler) = handlers.get_mut(&handler_idx) {
                        let (tx, rx) = oneshot::channel();
                        handler.process(peers[origin_idx].public_key(), request.clone(), tx);

                        if should_respond && let Ok(response) = rx.await {
                            assert_eq!(response.id, request.id);
                        }
                    }
                }

                CollectorOperation::MonitorCollected {
                    peer_idx,
                    response,
                    count,
                } => {
                    let monitor_idx = (peer_idx as usize) % peers.len();
                    let handler_idx = (peer_idx as usize) % peers.len();

                    if let Some(monitor) = monitors.get_mut(&monitor_idx) {
                        monitor.collected(peers[handler_idx].public_key(), response, count);
                    }
                }

                CollectorOperation::CreateEngine {
                    peer_idx,
                    mailbox_size,
                    priority_request,
                    priority_response,
                } => {
                    let idx = (peer_idx as usize) % peers.len();
                    let mailbox_size = usize::from(mailbox_size.max(MIN_BUFFER_SIZE));
                    let mailbox_size = NonZeroUsize::new(mailbox_size).unwrap();
                    let handler = handlers
                        .get(&idx)
                        .cloned()
                        .unwrap_or_else(|| FuzzHandler::new(true, TestRng::new(rng.random())));
                    let monitor = monitors.get(&idx).cloned().unwrap_or_else(FuzzMonitor::new);
                    let config = Config {
                        blocker: FuzzBlocker,
                        monitor,
                        handler,
                        mailbox_size,
                        priority_request,
                        request_codec: RangeCfg::from(..=MAX_LEN),
                        priority_response,
                        response_codec: RangeCfg::from(..=MAX_LEN),
                    };

                    let (engine, mailbox) = Engine::new(
                        context.child("engine").with_attribute("instance", restarts),
                        config,
                    );
                    restarts += 1;
                    mailboxes.insert(idx, mailbox);

                    let (_tx, _rx) = mpsc::unbounded_channel();
                    let mock_receiver = MockReceiver { rx: _rx };
                    engine.start(
                        (MockSender, mock_receiver),
                        (
                            MockSender,
                            MockReceiver {
                                rx: mpsc::unbounded_channel().1,
                            },
                        ),
                    );
                }
            }
            context.sleep(Duration::from_millis(100)).await;
        }
    });
}

fuzz_target!(|input: FuzzInput| {
    fuzz(input);
});
