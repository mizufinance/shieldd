use commonware_cryptography::bls12381::primitives::{ops, variant::MinSig};
use commonware_utils::test_rng;
use criterion::{BatchSize, Criterion, criterion_group};
use std::hint::black_box;

fn bench_combine_public_keys(c: &mut Criterion) {
    let mut rng = test_rng();
    for n in [10, 100, 1000, 10000].into_iter() {
        c.bench_function(&format!("{}/pks={}", module_path!(), n), |b| {
            b.iter_batched(
                || {
                    let mut public_keys = Vec::with_capacity(n);
                    for _ in 0..n {
                        let public_key = ops::keypair::<_, MinSig>(&mut rng).1;
                        public_keys.push(public_key);
                    }
                    public_keys
                },
                |public_keys| {
                    black_box(ops::aggregate::combine_public_keys::<MinSig, _>(
                        &public_keys,
                    ));
                },
                BatchSize::SmallInput,
            );
        });
    }
}

criterion_group! {
    name = benches;
    config = Criterion::default().sample_size(10);
    targets = bench_combine_public_keys
}
