//! Test fixtures for Ed25519 certificate signing schemes.

use crate::{
    Signer as _,
    certificate::{Scheme, mocks::Fixture},
    ed25519::{PrivateKey, PublicKey},
};
use commonware_math::algebra::Random;
use commonware_utils::{
    TryCollect as _,
    ordered::{Map, Set},
};
use rand_core::CryptoRng;

/// Generates ed25519 identity participants.
pub fn participants<R>(rng: &mut R, n: u32) -> Map<PublicKey, PrivateKey>
where
    R: CryptoRng,
{
    (0..n)
        .map(|_| {
            let private_key = PrivateKey::random(&mut *rng);
            let public_key = private_key.public_key();
            (public_key, private_key)
        })
        .try_collect()
        .expect("ed25519 public keys are unique")
}

/// Builds ed25519 identities alongside a caller-provided ed25519 certificate scheme wrapper.
pub fn fixture<S, R>(
    rng: &mut R,
    namespace: &[u8],
    n: u32,
    signer: impl Fn(&[u8], Set<PublicKey>, PrivateKey) -> Option<S>,
    verifier: impl Fn(&[u8], Set<PublicKey>) -> S,
) -> Fixture<S>
where
    R: CryptoRng,
    S: Scheme<PublicKey = PublicKey>,
{
    assert!(n > 0);

    let associated = participants(rng, n);
    let participants = associated.keys().clone();
    let participants_vec: Vec<_> = participants.clone().into();

    let private_keys: Vec<_> = participants_vec
        .iter()
        .map(|pk| {
            associated
                .get_value(pk)
                .expect("participant key must have an associated private key")
                .clone()
        })
        .collect();

    let schemes = private_keys
        .iter()
        .cloned()
        .map(|sk| {
            signer(namespace, participants.clone(), sk)
                .expect("scheme signer must be a participant")
        })
        .collect();
    let verifier = verifier(namespace, participants);

    Fixture {
        participants: participants_vec,
        private_keys,
        schemes,
        verifier,
    }
}
