//! `clean` subcommand for `ec2`

use crate::aws::{
    Error, MONITORING_REGION,
    s3::{
        self, delete_bucket_and_contents, delete_bucket_config, get_bucket_name_if_exists,
        is_no_such_bucket_error,
    },
};
use aws_config::Region;
use tracing::info;

/// Deletes the shared deployer caches and their contents.
pub async fn clean() -> Result<(), Error> {
    // Use the persisted name only: minting a fresh one here would overwrite the pointer to the
    // real bucket and orphan it.
    let Some(bucket_name) = get_bucket_name_if_exists() else {
        info!("no bucket config found, nothing to clean");
        return Ok(());
    };
    info!(bucket = bucket_name.as_str(), "cleaning S3 bucket");

    // Create S3 client in the monitoring region (where bucket is located)
    let s3_client = s3::create_client(Region::new(MONITORING_REGION)).await;

    // Delete all objects and the bucket itself
    match delete_bucket_and_contents(&s3_client, &bucket_name).await {
        Ok(()) => {
            info!(bucket = bucket_name.as_str(), "cleaned S3 bucket");
        }
        Err(e) => {
            if is_no_such_bucket_error(&e) {
                info!(
                    bucket = bucket_name.as_str(),
                    "bucket does not exist, nothing to clean"
                );
            } else {
                return Err(e);
            }
        }
    }

    // Delete the config file so a new bucket name is generated on next use
    delete_bucket_config();
    info!(bucket = bucket_name.as_str(), "deleted bucket config");

    Ok(())
}
