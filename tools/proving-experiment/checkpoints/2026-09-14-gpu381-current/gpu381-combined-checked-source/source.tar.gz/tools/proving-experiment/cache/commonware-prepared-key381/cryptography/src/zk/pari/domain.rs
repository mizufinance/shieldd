use super::Error;
use crate::bls12381::primitives::group::Scalar;
use commonware_math::{
    algebra::{Additive, Field, Ring},
    ntt::Domain as FftDomain,
    poly::Poly,
};
type Polynomial = Poly<Scalar>;

/// Canonical retained roots: all FFT roots except indices 1 modulo 4.
pub struct SubsetDomain {
    fft: FftDomain<Scalar>,
    retained: usize,
    removed: usize,
    excluded: Scalar,
}
impl SubsetDomain {
    pub fn valid_size(m: usize) -> bool {
        let Some(n) = m.checked_next_power_of_two() else {
            return false;
        };
        n >= 4 && n <= 1 << 20 && m == n - n / 4
    }
    pub fn capacity_size(required: usize) -> Option<usize> {
        let n = required
            .checked_mul(4)?
            .checked_add(2)?
            .checked_div(3)?
            .max(4)
            .checked_next_power_of_two()?;
        let m = n - n / 4;
        Self::valid_size(m).then_some(m)
    }
    pub fn new(m: usize) -> Result<Self, Error> {
        if !Self::valid_size(m) {
            return Err(Error::RelationMismatch);
        }
        let n = m.next_power_of_two();
        let removed = n / 4;
        let fft = FftDomain::<Scalar>::new(n)?;
        let excluded = fft.generator().exp(&[removed as u64]);
        Ok(Self {
            fft,
            retained: m,
            removed,
            excluded,
        })
    }
    pub const fn size(&self) -> usize {
        self.retained
    }
    pub fn fft_size(&self) -> usize {
        self.fft.size()
    }
    pub fn fft(&self) -> &FftDomain<Scalar> {
        &self.fft
    }
    fn root_index(&self, index: usize) -> usize {
        4 * (index / 3) + if index % 3 == 0 { 0 } else { index % 3 + 1 }
    }
    pub fn element(&self, index: usize) -> Result<Scalar, Error> {
        if index >= self.retained {
            return Err(Error::RelationMismatch);
        }
        Ok(self.fft.element(self.root_index(index))?)
    }
    pub fn evaluate_vanishing(&self, point: &Scalar) -> Scalar {
        let t = point.exp(&[self.removed as u64]);
        let (mut result, mut power) = (Scalar::zero(), Scalar::one());
        for _ in 0..4 {
            result = result * &t + &power;
            power *= &self.excluded;
        }
        result
    }
    pub fn lagrange_basis(&self, point: &Scalar) -> Vec<Scalar> {
        self.lagrange_basis_at(point, &(0..self.retained as u32).collect::<Vec<_>>())
            .expect("canonical domain indices")
    }
    pub fn lagrange_basis_at(&self, point: &Scalar, indices: &[u32]) -> Result<Vec<Scalar>, Error> {
        if indices.iter().any(|i| *i as usize >= self.retained) {
            return Err(Error::RelationMismatch);
        }
        let vanishing = self.evaluate_vanishing(point);
        let roots = indices
            .iter()
            .map(|i| self.element(*i as usize))
            .collect::<Result<Vec<_>, _>>()?;
        if vanishing == Scalar::zero() {
            return Ok(roots
                .iter()
                .map(|h| {
                    if h == point {
                        Scalar::one()
                    } else {
                        Scalar::zero()
                    }
                })
                .collect());
        }
        let mut products = Vec::with_capacity(roots.len());
        let mut product = Scalar::one();
        for h in &roots {
            products.push(product.clone());
            product *= &(point.clone() - h);
        }
        if product == Scalar::zero() {
            return Err(Error::RelationMismatch);
        }
        let mut inverse = product.inv();
        let mut denominators = vec![Scalar::zero(); roots.len()];
        for i in (0..roots.len()).rev() {
            denominators[i] = inverse.clone() * &products[i];
            inverse *= &(point.clone() - &roots[i]);
        }
        let scale = vanishing * &Scalar::from_limbs([self.fft_size() as u64, 0, 0, 0]).inv();
        Ok(roots
            .iter()
            .zip(denominators)
            .map(|(h, inverse)| {
                let z = h.exp(&[self.removed as u64]) - &self.excluded;
                scale.clone() * h * &z * &inverse
            })
            .collect())
    }
    pub fn interpolate(&self, values: &[Scalar]) -> Result<Vec<Scalar>, Error> {
        self.interpolate_with(values, &Scalar::one(), |weighted| Ok(self.fft.interpolate(weighted)?))
    }
    pub(super) fn interpolate_with(
        &self, values: &[Scalar], inverse_scale: &Scalar,
        inverse: impl FnOnce(&[Scalar]) -> Result<Vec<Scalar>, Error>,
    ) -> Result<Vec<Scalar>, Error> {
        if values.len() > self.retained {
            return Err(Error::RelationMismatch);
        }
        let mut weighted = vec![Scalar::zero(); self.fft_size()];
        let mut weights = Vec::with_capacity(4);
        let mut power = Scalar::one();
        for _ in 0..4 {
            weights.push((power.clone() - &self.excluded) * inverse_scale);
            power *= &self.excluded;
        }
        for (i, v) in values.iter().enumerate() {
            let j = self.root_index(i);
            weighted[j] = v.clone() * &weights[j % 4];
        }
        let mut coefficients = inverse(&weighted)?;
        let mut result = vec![Scalar::zero(); self.retained];
        for i in (self.removed..self.fft_size()).rev() {
            result[i - self.removed] = coefficients[i].clone();
            let term = coefficients[i].clone() * &self.excluded;
            coefficients[i - self.removed] += &term;
        }
        if coefficients[..self.removed]
            .iter()
            .any(|c| *c != Scalar::zero())
        {
            return Err(Error::Unsatisfied);
        }
        Ok(result)
    }
    pub fn polynomial(&self, values: &[Scalar]) -> Result<Polynomial, Error> {
        Polynomial::from_coefficients(self.interpolate(values)?).ok_or(Error::TooLarge)
    }
    pub fn multiply_vanishing(&self, poly: &Polynomial) -> Result<Polynomial, Error> {
        let mut result = vec![
            Scalar::zero();
            poly.coefficients()
                .len()
                .checked_add(self.retained)
                .ok_or(Error::TooLarge)?
        ];
        let mut weights = vec![Scalar::one(); 4];
        for i in (0..3).rev() {
            weights[i] = weights[i + 1].clone() * &self.excluded;
        }
        for (j, weight) in weights.iter().enumerate() {
            for (i, c) in poly.coefficients().iter().enumerate() {
                result[i + j * self.removed] += &(c.clone() * weight);
            }
        }
        Polynomial::from_coefficients(result).ok_or(Error::TooLarge)
    }
    pub fn mask(&self, poly: &Polynomial, mask: &Polynomial) -> Result<Polynomial, Error> {
        Ok(poly.clone() + &self.multiply_vanishing(mask)?)
    }
    pub fn divide(&self, poly: &Polynomial) -> Result<(Polynomial, Polynomial), Error> {
        let mut remainder = poly.coefficients().to_vec();
        let mut quotient =
            vec![Scalar::zero(); remainder.len().saturating_sub(self.retained).max(1)];
        let mut weights = vec![Scalar::one(); 4];
        for i in (0..3).rev() {
            weights[i] = weights[i + 1].clone() * &self.excluded;
        }
        for degree in (self.retained..remainder.len()).rev() {
            let coefficient = remainder[degree].clone();
            quotient[degree - self.retained] = coefficient.clone();
            for (j, weight) in weights.iter().enumerate() {
                remainder[degree - self.retained + j * self.removed] -=
                    &(coefficient.clone() * weight);
            }
        }
        remainder.truncate(self.retained.min(remainder.len()).max(1));
        let mut q = Polynomial::from_coefficients(quotient).ok_or(Error::TooLarge)?;
        let mut r = Polynomial::from_coefficients(remainder).ok_or(Error::TooLarge)?;
        q.trim();
        r.trim();
        Ok((q, r))
    }
    pub fn coset_inverse(&self, shift: &Scalar) -> Result<Vec<Scalar>, Error> {
        let zh = self.fft.evaluate_vanishing(shift);
        if zh == Scalar::zero() {
            return Err(Error::RelationMismatch);
        }
        let factor = zh.inv();
        let gs = shift.exp(&[self.removed as u64]);
        let mut root = Scalar::one();
        let mut result = Vec::with_capacity(4);
        for _ in 0..4 {
            result.push((gs.clone() * &root - &self.excluded) * &factor);
            root *= &self.excluded;
        }
        Ok(result)
    }
}

#[cfg(test)]
mod tests {
    use crate::{bls12381::primitives::group::Scalar, zk::pari::SubsetDomain};
    use commonware_math::{
        algebra::{Additive, FieldNTT, Ring},
        poly::Poly,
    };
    type Polynomial = Poly<Scalar>;

    #[test]
    fn retained_roots_interpolation_masks_division_and_removed_root_poles() {
        for n in [4, 8, 16, 32, 128] {
            let d = SubsetDomain::new(n - n / 4).unwrap();
            let indices = (0..n).filter(|i| i % 4 != 1).collect::<Vec<_>>();
            let values = (0..d.size())
                .map(|i| Scalar::from(i as u64 + 11))
                .collect::<Vec<_>>();
            let a = d.polynomial(&values).unwrap();
            let full = d.fft().evaluate(a.coefficients()).unwrap();
            for ((i, index), value) in indices.iter().enumerate().zip(&values) {
                assert_eq!(d.element(i).unwrap(), d.fft().element(*index).unwrap());
                assert_eq!(&full[*index], value);
            }
            let product = d.multiply_vanishing(&a).unwrap();
            let (q, r) = d.divide(&product).unwrap();
            let mut expected = a.clone();
            expected.trim();
            assert_eq!(q, expected);
            assert_eq!(r, Polynomial::zero());
            let mask =
                Polynomial::from_coefficients(vec![Scalar::from(13), Scalar::from(17)]).unwrap();
            let masked = d.mask(&a, &mask).unwrap();
            let (q, mut r) = d.divide(&masked).unwrap();
            r.trim();
            assert_eq!(q, mask);
            assert_eq!(r, expected);
            for index in 0..n {
                let point = d.fft().element(index).unwrap();
                let weights = d.lagrange_basis(&point);
                let value = values
                    .iter()
                    .zip(weights)
                    .fold(Scalar::zero(), |sum, (v, w)| sum + &(v.clone() * &w));
                assert_eq!(value, a.eval(&point));
                let oracle = indices.iter().fold(Scalar::one(), |p, i| {
                    p * &(point.clone() - &d.fft().element(*i).unwrap())
                });
                assert_eq!(d.evaluate_vanishing(&point), oracle);
                assert_eq!(oracle == Scalar::zero(), index % 4 != 1);
                if index % 4 != 1 {
                    assert_eq!(masked.eval(&point), a.eval(&point));
                }
                assert!(d.coset_inverse(&point).is_err());
            }
            let shift = Scalar::coset_shift();
            let inverses = d.coset_inverse(&shift).unwrap();
            assert_eq!(inverses.len(), 4);
            for i in 0..n {
                let point = shift.clone() * &d.fft().element(i).unwrap();
                assert_eq!(
                    inverses[i % 4].clone() * &d.evaluate_vanishing(&point),
                    Scalar::one()
                );
            }
            let zero = d.polynomial(&[]).unwrap();
            assert_eq!(zero.eval(&shift), Scalar::zero());
            let short = d.polynomial(&values[..1]).unwrap();
            for (i, index) in indices.iter().enumerate() {
                assert_eq!(
                    short.eval(&d.fft().element(*index).unwrap()),
                    if i == 0 {
                        values[0].clone()
                    } else {
                        Scalar::zero()
                    }
                );
            }
        }
    }

    #[test]
    fn domain_descriptor_and_buffer_bounds_reject_old_domain() {
        for m in [
            0,
            1,
            2,
            4,
            7,
            8,
            15,
            196607,
            196609,
            229376,
            262144,
            1 << 21,
            usize::MAX,
        ] {
            assert!(SubsetDomain::new(m).is_err(), "{m}");
        }
        for (required, expected) in [
            (0, 3),
            (3, 3),
            (4, 6),
            (6, 6),
            (7, 12),
            (191516, 196608),
            (196608, 196608),
            (196609, 393216),
            (786432, 786432),
        ] {
            assert_eq!(SubsetDomain::capacity_size(required), Some(expected));
        }
        for required in [786433, usize::MAX] {
            assert_eq!(SubsetDomain::capacity_size(required), None);
        }
        let d = SubsetDomain::new(3).unwrap();
        assert!(d.element(3).is_err());
        assert!(d.interpolate(&vec![Scalar::zero(); 4]).is_err());
        assert!(d.lagrange_basis_at(&Scalar::one(), &[3]).is_err());
    }
}
