use commonware_cryptography::{
    Signer,
    bls12381::{
        dkg::feldman_desmedt::deal,
        primitives::{self, sharing::Mode, variant::MinSig},
    },
    ed25519::PrivateKey,
};
use commonware_parallel::Sequential;
use commonware_utils::{Faults, N3f1, TryCollect, test_rng};
use criterion::{BatchSize, Criterion, criterion_group};
use std::hint::black_box;

fn bench_threshold_recover(c: &mut Criterion) {
    let mut rng = test_rng();
    let namespace = b"benchmark";
    let msg = b"hello";
    for mode in [Mode::NonZeroCounter, Mode::RootsOfUnity] {
        for &n in &[5, 10, 20, 50, 100, 250, 500, 1000, 2000, 4000] {
            let t = N3f1::quorum(n);
            c.bench_function(
                &format!("{}/mode={:?} n={} t={}", module_path!(), mode, n, t),
                |b| {
                    b.iter_batched(
                        || {
                            let players = (0..n)
                                .map(|i| PrivateKey::from_seed(i as u64).public_key())
                                .try_collect()
                                .unwrap();
                            let (public, shares) = deal::<MinSig, _, N3f1>(&mut rng, mode, players)
                                .expect("deal should succeed");
                            (
                                public,
                                shares
                                    .values()
                                    .iter()
                                    .map(|s| {
                                        primitives::ops::threshold::sign_message::<MinSig>(
                                            s, namespace, msg,
                                        )
                                    })
                                    .collect::<Vec<_>>(),
                            )
                        },
                        |(public, partials)| {
                            black_box(
                                primitives::ops::threshold::recover(
                                    public.public(),
                                    &partials,
                                    &Sequential,
                                )
                                .unwrap(),
                            );
                        },
                        BatchSize::SmallInput,
                    );
                },
            );
        }
    }
}

criterion_group!(benches, bench_threshold_recover);
