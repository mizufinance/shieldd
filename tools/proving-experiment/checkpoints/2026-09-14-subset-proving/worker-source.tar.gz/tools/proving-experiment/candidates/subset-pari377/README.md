# Subset-domain Pari377 candidate

Development-only complete-path candidate following the actual six-assignment polynomial screen. This workspace preserves the current original/outlined Transfer relation and changes its polynomial interpolation domain. The checked domain descriptor, new development key codec, setup, masks and verifier must agree. No production integration or inherited audit approval is implied.

Implementation is in progress; there are no subset keys, proofs or full-API measurements yet. Existing worker binaries and measured matrices stay frozen. See the parent STATUS.md and the subset polynomial screen for completed evidence.
