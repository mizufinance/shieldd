// src/shader/bls12_381/curve_g2.wgsl

// ============================================================================
// EXTENSION FIELD ARITHMETIC (F_q^2)
// Required for G2 Curve elements (the 'B' element in Groth16)
// BLS12-381 F_q^2 is defined as F_q[u] / (u^2 + 1)
// ============================================================================

struct Fq2 {
    c0: U384,
    c1: U384,
}

fn add_fp2(a: Fq2, b: Fq2) -> Fq2 {
    return Fq2(add_mod_q(a.c0, b.c0), add_mod_q(a.c1, b.c1));
}

fn sub_fp2(a: Fq2, b: Fq2) -> Fq2 {
    return Fq2(sub_mod_q(a.c0, b.c0), sub_mod_q(a.c1, b.c1));
}

// (a0 + a1*u) * (b0 + b1*u) = (a0*b0 - a1*b1) + (a0*b1 + a1*b0)*u
fn mul_fp2(a: Fq2, b: Fq2) -> Fq2 {
    let a0b0 = mul_montgomery_u384(a.c0, b.c0);
    let a1b1 = mul_montgomery_u384(a.c1, b.c1);

    // a0b1 + a1b0 = (a0 + a1)*(b0 + b1) - a0b0 - a1b1
    // Sums only feed mul_montgomery, which handles inputs < 2q < R
    let a0_plus_a1 = add_u384(a.c0, a.c1);
    let b0_plus_b1 = add_u384(b.c0, b.c1);
    let a_plus_b_prod = mul_montgomery_u384(a0_plus_a1, b0_plus_b1);

    var c1_out = sub_mod_q(a_plus_b_prod, a0b0);
    c1_out = sub_mod_q(c1_out, a1b1);

    let c0_out = sub_mod_q(a0b0, a1b1);

    return Fq2(c0_out, c1_out);
}

// Squaring in Fq2: (a0 + a1*u)^2 = (a0^2 - a1^2) + (2*a0*a1)*u
// Uses 2 Fq muls instead of 3 for general multiplication (33% savings).
// c0 = (a0 + a1)(a0 - a1), c1 = 2 * a0 * a1
fn sqr_fp2(a: Fq2) -> Fq2 {
    // Sum only feeds mul_montgomery, which handles inputs < 2q < R
    let a0_plus_a1 = add_u384(a.c0, a.c1);
    let a0_minus_a1 = sub_mod_q(a.c0, a.c1);
    let c0_out = mul_montgomery_u384(a0_plus_a1, a0_minus_a1);
    let a0a1 = mul_montgomery_u384(a.c0, a.c1);
    let c1_out = add_mod_q(a0a1, a0a1);
    return Fq2(c0_out, c1_out);
}

// Multiply a reduced Fq element by 12 (mod q) using repeated doubling.
// 12x = 8x + 4x. Each step uses add_mod_q to stay in [0, q).
fn mul_by_12_mod_q(a: U384) -> U384 {
    let x2 = add_mod_q(a, a);
    let x4 = add_mod_q(x2, x2);
    let x8 = add_mod_q(x4, x4);
    return add_mod_q(x8, x4);
}

// Multiply Fq2 element by 3b = Fq2(12, 12) for BLS12-381 G2 (b = 4(1+i)).
// (a0 + a1*u) * (12 + 12*u) = 12*(a0 - a1) + 12*(a0 + a1)*u
fn mul_by_b3_fp2(a: Fq2) -> Fq2 {
    let diff = sub_mod_q(a.c0, a.c1);
    let sum = add_mod_q(a.c0, a.c1);
    return Fq2(mul_by_12_mod_q(diff), mul_by_12_mod_q(sum));
}

// ============================================================================
// G2 CURVE ARITHMETIC (Extension Field F_q^2)
// ============================================================================

struct PointG2 {
    x: Fq2,
    y: Fq2,
    z: Fq2,
}

// Complete addition formula for G2 (Renes-Costello-Batina 2015, EFD add-2015-rcb, a=0).
// Handles all cases: P+Q, P+P (doubling), P+(-P), P+O, O+P in a single branchless formula.
// Uses PROJECTIVE coordinates (not Jacobian): affine (x,y) = (X/Z, Y/Z).
// Identity element is (0:1:0), not (0:0:0).
// Eliminates double_g2 from the call graph (avoids Metal shader miscompilation).
// BLS12-381 G2: y² = x³ + 4(1+i), b = 4(1+i), 3b = 12(1+i) = Fq2(12, 12).
// Cost: 12 Fq2 multiplications + 2 cheap mul-by-b3.
fn add_g2_complete(p1: PointG2, p2: PointG2) -> PointG2 {
    let t0 = mul_fp2(p1.x, p2.x);                                    // M1
    let t1 = mul_fp2(p1.y, p2.y);                                    // M2
    let t2 = mul_fp2(p1.z, p2.z);                                    // M3
    let t3 = sub_fp2(sub_fp2(mul_fp2(add_fp2(p1.x, p1.y),           // M4
                                      add_fp2(p2.x, p2.y)), t0), t1); // X1Y2+X2Y1
    let t4 = sub_fp2(sub_fp2(mul_fp2(add_fp2(p1.x, p1.z),           // M5
                                      add_fp2(p2.x, p2.z)), t0), t2); // X1Z2+X2Z1
    let t5 = sub_fp2(sub_fp2(mul_fp2(add_fp2(p1.y, p1.z),           // M6
                                      add_fp2(p2.y, p2.z)), t1), t2); // Y1Z2+Y2Z1

    let c1 = mul_by_b3_fp2(t2);                                      // cheap: b3 * Z1Z2
    let x_tmp = sub_fp2(t1, c1);                                     // Y1Y2 - b3*Z1Z2
    let z_tmp = add_fp2(t1, c1);                                     // Y1Y2 + b3*Z1Z2

    let y3_a = mul_fp2(x_tmp, z_tmp);                                // M7: (Y1Y2)²-(b3*Z1Z2)²

    let t1n = add_fp2(add_fp2(t0, t0), t0);                          // 3*X1X2 (additions only)
    let c2 = mul_by_b3_fp2(t4);                                      // cheap: b3*(X1Z2+X2Z1)

    let y_corr = mul_fp2(t1n, c2);                                   // M8: 3*X1X2 * b3*(X1Z2+X2Z1)
    let y3 = add_fp2(y3_a, y_corr);

    let x3_a = mul_fp2(t3, x_tmp);                                   // M9: (X1Y2+X2Y1)*(Y1Y2-b3*Z1Z2)
    let x3_b = mul_fp2(t5, c2);                                      // M10: (Y1Z2+Y2Z1)*b3*(X1Z2+X2Z1)
    let x3 = sub_fp2(x3_a, x3_b);

    let z3_a = mul_fp2(t5, z_tmp);                                   // M11: (Y1Z2+Y2Z1)*(Y1Y2+b3*Z1Z2)
    let z3_b = mul_fp2(t3, t1n);                                     // M12: (X1Y2+X2Y1)*3*X1X2
    let z3 = add_fp2(z3_a, z3_b);

    return PointG2(x3, y3, z3);
}

// Computes 2 * P in Jacobian coordinates for G2.
// BLS12-381 G2 curve: y^2 = x^3 + 4(1+i). (a = 0)
fn double_g2(p: PointG2) -> PointG2 {
    // XX = X^2
    let xx = sqr_fp2(p.x);
    // YY = Y^2
    let yy = sqr_fp2(p.y);
    // YYYY = YY^2
    let yyyy = sqr_fp2(yy);

    // S = 2 * ((X + YY)^2 - XX - YYYY)
    let x_plus_yy = add_fp2(p.x, yy);
    let x_plus_yy_sq = sqr_fp2(x_plus_yy);
    var s = sub_fp2(x_plus_yy_sq, xx);
    s = sub_fp2(s, yyyy);
    s = add_fp2(s, s); // * 2

    // M = 3 * XX (since a = 0)
    let m = add_fp2(add_fp2(xx, xx), xx);

    // T = M^2 - 2*S
    let m_sq = sqr_fp2(m);
    let t = sub_fp2(m_sq, add_fp2(s, s));

    // X_out = T
    let x_out = t;

    // Y_out = M * (S - T) - 8 * YYYY
    let s_minus_t = sub_fp2(s, t);
    let m_times_s_minus_t = mul_fp2(m, s_minus_t);
    var eight_yyyy = add_fp2(yyyy, yyyy); // 2
    eight_yyyy = add_fp2(eight_yyyy, eight_yyyy); // 4
    eight_yyyy = add_fp2(eight_yyyy, eight_yyyy); // 8
    let y_out = sub_fp2(m_times_s_minus_t, eight_yyyy);

    // Z_out = (Y + Z)^2 - YY - ZZ
    let zz = sqr_fp2(p.z);
    let y_plus_z = add_fp2(p.y, p.z);
    let y_plus_z_sq = sqr_fp2(y_plus_z);
    var z_out = sub_fp2(y_plus_z_sq, yy);
    z_out = sub_fp2(z_out, zz);

    return PointG2(x_out, y_out, z_out);
}

// Computes P1 + P2 in Jacobian coordinates for G2.
fn add_g2(p1: PointG2, p2: PointG2) -> PointG2 {
    // Z1Z1 = Z1^2
    let z1z1 = sqr_fp2(p1.z);
    // Z2Z2 = Z2^2
    let z2z2 = sqr_fp2(p2.z);

    // U1 = X1 * Z2Z2
    let u1 = mul_fp2(p1.x, z2z2);
    // U2 = X2 * Z1Z1
    let u2 = mul_fp2(p2.x, z1z1);

    // S1 = Y1 * Z2 * Z2Z2
    let s1 = mul_fp2(mul_fp2(p1.y, p2.z), z2z2);
    // S2 = Y2 * Z1 * Z1Z1
    let s2 = mul_fp2(mul_fp2(p2.y, p1.z), z1z1);

    // Explicitly handle edge cases where incomplete Jacobian addition fails.
    var u_eq = true;
    for (var i = 0u; i < 30u; i = i + 1u) {
        if u1.c0.limbs[i] != u2.c0.limbs[i] || u1.c1.limbs[i] != u2.c1.limbs[i] {
            u_eq = false;
            break;
        }
    }

    if u_eq {
        var s_eq = true;
        for (var i = 0u; i < 30u; i = i + 1u) {
            if s1.c0.limbs[i] != s2.c0.limbs[i] || s1.c1.limbs[i] != s2.c1.limbs[i] {
                s_eq = false;
                break;
            }
        }
        if s_eq {
            return double_g2(p1);
        } else {
            return PointG2(Fq2(U384(array<u32,30>(0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u)), U384(array<u32,30>(0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u))), Fq2(U384(array<u32,30>(0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u)), U384(array<u32,30>(0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u))), Fq2(U384(array<u32,30>(0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u)), U384(array<u32,30>(0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u))));
        }
    }

    // Jacobian add-2007-bl formula (EFD), lifted to Fp2.
    let h = sub_fp2(u2, u1);
    let two_h = add_fp2(h, h);
    let i = sqr_fp2(two_h);
    let j = mul_fp2(h, i);
    let s2_minus_s1 = sub_fp2(s2, s1);
    let r = add_fp2(s2_minus_s1, s2_minus_s1);
    let v = mul_fp2(u1, i);

    let r_sq = sqr_fp2(r);
    var x3 = sub_fp2(r_sq, j);
    x3 = sub_fp2(x3, add_fp2(v, v));

    let v_minus_x3 = sub_fp2(v, x3);
    let r_times_v_minus_x3 = mul_fp2(r, v_minus_x3);
    let two_s1 = add_fp2(s1, s1);
    let two_s1_j = mul_fp2(two_s1, j);
    let y3 = sub_fp2(r_times_v_minus_x3, two_s1_j);

    let z1_plus_z2 = add_fp2(p1.z, p2.z);
    let z1_plus_z2_sq = sqr_fp2(z1_plus_z2);
    let z1z2_factor = sub_fp2(sub_fp2(z1_plus_z2_sq, z1z1), z2z2);
    let z3 = mul_fp2(z1z2_factor, h);

    return PointG2(x3, y3, z3);
}

// Mixed addition: P1 (projective, arbitrary Z) + P2 (affine in Montgomery form, Z2 = (R,0)).
// When Z2 = (R,0) (Montgomery representation of (1,0) in Fq2), several terms simplify:
//   z2z2 = (R,0), u1 = X1, s1 = Y1, and z1z2_factor = 2*Z1.
// This saves 5 Fq2 multiplications compared to the full Jacobian addition
// (11 mul_fp2 vs 16 mul_fp2).
fn add_g2_mixed(p1: PointG2, p2: PointG2) -> PointG2 {
    // Z1Z1 = Z1^2
    let z1z1 = sqr_fp2(p1.z);

    // u1 = X1 (since Z2 = (R,0): X1 * z2z2 = X1)
    // u2 = X2 * Z1Z1
    let u2 = mul_fp2(p2.x, z1z1);

    // s1 = Y1 (since Z2 = (R,0): Y1 * Z2 * z2z2 = Y1)
    // s2 = Y2 * Z1 * Z1Z1
    let s2 = mul_fp2(mul_fp2(p2.y, p1.z), z1z1);

    // Check if U1 == U2 (doubling or cancellation)
    var u_eq = true;
    for (var i = 0u; i < 30u; i = i + 1u) {
        if p1.x.c0.limbs[i] != u2.c0.limbs[i] || p1.x.c1.limbs[i] != u2.c1.limbs[i] {
            u_eq = false;
            break;
        }
    }
    if u_eq {
        var s_eq = true;
        for (var i = 0u; i < 30u; i = i + 1u) {
            if p1.y.c0.limbs[i] != s2.c0.limbs[i] || p1.y.c1.limbs[i] != s2.c1.limbs[i] {
                s_eq = false;
                break;
            }
        }
        if s_eq { return double_g2(p1); } else {
            return PointG2(
                Fq2(U384(array<u32,30>(0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u)),
                    U384(array<u32,30>(0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u))),
                Fq2(U384(array<u32,30>(0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u)),
                    U384(array<u32,30>(0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u))),
                Fq2(U384(array<u32,30>(0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u)),
                    U384(array<u32,30>(0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u)))
            );
        }
    }

    // H = U2 - U1 = U2 - X1
    let h = sub_fp2(u2, p1.x);
    let two_h = add_fp2(h, h);
    let i_val = sqr_fp2(two_h);
    let j = mul_fp2(h, i_val);
    // r = 2*(S2 - S1) = 2*(S2 - Y1)
    let s2_minus_s1 = sub_fp2(s2, p1.y);
    let r = add_fp2(s2_minus_s1, s2_minus_s1);
    // V = U1 * I = X1 * I
    let v = mul_fp2(p1.x, i_val);

    let r_sq = sqr_fp2(r);
    var x3 = sub_fp2(r_sq, j);
    x3 = sub_fp2(x3, add_fp2(v, v));

    let v_minus_x3 = sub_fp2(v, x3);
    let r_times_v_minus_x3 = mul_fp2(r, v_minus_x3);
    let two_s1 = add_fp2(p1.y, p1.y);
    let two_s1_j = mul_fp2(two_s1, j);
    let y3 = sub_fp2(r_times_v_minus_x3, two_s1_j);

    // Z3: since Z2=(R,0), 2*Z1*Z2 = 2*Z1 in Montgomery
    let two_z1 = add_fp2(p1.z, p1.z);
    let z3 = mul_fp2(two_z1, h);

    return PointG2(x3, y3, z3);
}
