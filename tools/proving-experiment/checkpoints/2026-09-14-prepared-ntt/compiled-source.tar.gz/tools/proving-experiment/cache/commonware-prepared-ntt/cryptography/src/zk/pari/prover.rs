use super::prepared_ntt::PreparedTransform;
use super::SubsetDomain as Domain;
use super::{
    Claim, Error, Proof, ProvingKey, Relation, Witness, circuit::dot, sample_scalar,
    transcript_challenge, transcript_challenge_prebound,
};
use crate::{
    bls12381::primitives::group::{G1, Scalar},
    transcript::Transcript,
};
use commonware_math::{
    algebra::{Additive, Field, FieldNTT, Ring, Multiplicative, Space},
    ntt::Domain as FftDomain,
    poly::Poly,
};
type Polynomial = Poly<Scalar>;
use commonware_parallel::Strategy;
use rand_core::CryptoRng;

/// Non-overlapping development diagnostics; final samples use ordinary `prove`.
#[derive(Default, Clone, Debug)]
pub struct ProverTimings {
    pub input_validation_ns: u128,
    pub relation_evaluation_ns: u128,
    pub interpolation_ns: u128,
    pub masking_ns: u128,
    pub quotient_ns: u128,
    pub commitment_msm_ns: u128,
    pub opening_polynomials_ns: u128,
    pub opening_msm_ns: u128,
}

#[derive(Clone, Copy)]
pub enum QuotientMethod {
    Generic,
    Square,
}

/// Compute ((a + mask_a Z)^2 - (b + mask_b Z)) / Z, rejecting a nonzero remainder.
pub fn masked_quotient(
    a: &Polynomial,
    b: &Polynomial,
    mask_a: &Polynomial,
    mask_b: &Polynomial,
    size: usize,
) -> Result<Polynomial, Error> {
    if a.coefficients().len() > size
        || b.coefficients().len() > size
        || mask_a.coefficients().len() != 2
        || mask_b.coefficients().len() != 1
    {
        return Err(Error::RelationMismatch);
    }
    let length = a
        .coefficients()
        .len()
        .checked_mul(2)
        .and_then(|n| n.checked_sub(1))
        .ok_or(Error::TooLarge)?;
    let domain = FftDomain::new(length)?;
    let mut evaluations = domain.evaluate(a.coefficients())?;
    for value in &mut evaluations {
        value.square();
    }
    let mut coefficients = domain.interpolate(&evaluations)?;
    coefficients.truncate(length);
    let square = Polynomial::from_coefficients(coefficients).ok_or(Error::TooLarge)?;
    let (base, remainder) = Domain::new(size)?.divide(&(square - b))?;
    if remainder != Polynomial::zero() {
        return Err(Error::Unsatisfied);
    }
    expand_masks(base,a,mask_a,mask_b,size)
}
fn expand_masks(base:Polynomial,a:&Polynomial,mask_a:&Polynomial,mask_b:&Polynomial,size:usize)->Result<Polynomial,Error>{
    let [constant, linear] = mask_a.coefficients() else {
        return Err(Error::RelationMismatch);
    };
    let mut cross = vec![Scalar::zero(); a.coefficients().len() + 1];
    for (i, value) in a.coefficients().iter().enumerate() {
        cross[i] += &(value.clone() * &(constant.clone() + constant));
        cross[i + 1] += &(value.clone() * &(linear.clone() + linear));
    }
    let cross = Polynomial::from_coefficients(cross).ok_or(Error::TooLarge)?;
    let mask_square = Domain::new(size)?.multiply_vanishing(&mask_a.multiply(mask_a)?)?;
    let mut quotient = base + &cross + &mask_square - mask_b;
    quotient.trim();
    Ok(quotient)
}

/// Runs the same prover with separately reported diagnostic stage timers.
pub fn prove_profiled(
    rng: &mut impl CryptoRng,
    transcript: &mut Transcript,
    proving_key: &ProvingKey,
    relation: &Relation,
    claim: &Claim,
    witness: &Witness,
    strategy: &impl Strategy,
    quotient_method: QuotientMethod,
) -> Result<(Proof, ProverTimings), Error> {
    let mut timings = ProverTimings::default();
    let proof = prove_inner(
        rng,
        transcript,
        proving_key,
        relation,
        claim,
        witness,
        strategy,
        true,
        quotient_method,
        None,
        Some(&mut timings),
        &mut |points, scalars| Ok(G1::msm(points, scalars, strategy)),
    )?;
    Ok((proof, timings))
}

/// Create a zero-knowledge proof for a claim and compiled witness.
pub fn prove(
    rng: &mut impl CryptoRng,
    transcript: &mut Transcript,
    proving_key: &ProvingKey,
    relation: &Relation,
    claim: &Claim,
    witness: &Witness,
    strategy: &impl Strategy,
) -> Result<Proof, Error> {
    prove_inner(
        rng,
        transcript,
        proving_key,
        relation,
        claim,
        witness,
        strategy,
        true,
        QuotientMethod::Square,
        None,
        None,
        &mut |points, scalars| Ok(G1::msm(points, scalars, strategy)),
    )
}

/// Create a proof whose statement the caller has already bound to the
/// transcript.
///
/// # Security
///
/// The Fiat-Shamir challenge only covers what the transcript contains. Before
/// calling, the caller MUST have committed the claim's public inputs and every
/// block commitment (or data that uniquely determines them) to `transcript`,
/// and the verifier must replay exactly the same binding. Use [`prove`] unless
/// the statement needs a custom transcript encoding (e.g. binding commitment
/// preimages so batch verification can fold derived commitments).
#[allow(clippy::too_many_arguments)]
pub fn prove_prebound(
    rng: &mut impl CryptoRng,
    transcript: &mut Transcript,
    proving_key: &ProvingKey,
    relation: &Relation,
    claim: &Claim,
    witness: &Witness,
    strategy: &impl Strategy,
) -> Result<Proof, Error> {
    prove_inner(
        rng,
        transcript,
        proving_key,
        relation,
        claim,
        witness,
        strategy,
        false,
        QuotientMethod::Square,
        None,
        None,
        &mut |points, scalars| Ok(G1::msm(points, scalars, strategy)),
    )
}

/// Ordinary proving with a development-only group-arithmetic boundary.
pub fn prove_with_msm(
    rng: &mut impl CryptoRng,
    transcript: &mut Transcript,
    proving_key: &ProvingKey,
    relation: &Relation,
    claim: &Claim,
    witness: &Witness,
    strategy: &impl Strategy,
    msm: &mut dyn FnMut(&[G1], &[Scalar]) -> Result<G1, Error>,
) -> Result<Proof, Error> {
    prove_inner(
        rng,
        transcript,
        proving_key,
        relation,
        claim,
        witness,
        strategy,
        true,
        QuotientMethod::Square,
        None,
        None,
        msm,
    )
}

#[allow(clippy::too_many_arguments)]
fn prove_inner(
    rng: &mut impl CryptoRng,
    transcript: &mut Transcript,
    proving_key: &ProvingKey,
    relation: &Relation,
    claim: &Claim,
    witness: &Witness,
    strategy: &impl Strategy,
    bind_claim: bool,
    quotient_method: QuotientMethod,
    prepared: Option<&PreparedPolynomials>,
    mut timings: Option<&mut ProverTimings>,
    msm: &mut dyn FnMut(&[G1], &[Scalar]) -> Result<G1, Error>,
) -> Result<Proof, Error> {
    let mut clock = timings.as_ref().map(|_| std::time::Instant::now());
    macro_rules! stage {
        ($field:ident) => {
            if let (Some(timings), Some(clock)) = (timings.as_mut(), clock.as_mut()) {
                timings.$field = clock.elapsed().as_nanos();
                *clock = std::time::Instant::now();
            }
        };
    }

    validate_inputs(proving_key, relation, claim, witness, strategy)?;

    stage!(input_validation_ns);
    let assignment = witness.assignment();
    let values = assignment.values();
    let domain = Domain::new(relation.size())?;
    let (z_a_evaluations, z_b_evaluations) = evaluate_relation(relation, values);
    let public = assignment.public_assignment();
    if prepared.is_some() && z_a_evaluations.iter().zip(&z_b_evaluations).any(|(a,b)| a.clone()*a != *b) {
        return Err(Error::Unsatisfied);
    }
    let public_evaluations = if prepared.is_none(){Some(evaluate_public(relation,public))}else{None};

    stage!(relation_evaluation_ns);
    let (z_a, z_b) = if let Some(prepared) = prepared {
        (prepared.polynomial(&z_a_evaluations)?, prepared.polynomial(&z_b_evaluations)?)
    } else {
        (domain.polynomial(&z_a_evaluations)?, domain.polynomial(&z_b_evaluations)?)
    };
    let (x_a,x_b) = if let Some(prepared)=prepared {prepared.public(relation,public)?}else{
        let(a,b)=public_evaluations.expect("unprepared evaluations");
        (domain.polynomial(&a)?,domain.polynomial(&b)?)
    };

    stage!(interpolation_ns);
    let eta_1 = sample_scalar(rng);
    let eta_2 = sample_scalar(rng);
    let a_mask =
        Polynomial::from_coefficients(vec![eta_1.clone(), eta_2.clone()]).ok_or(Error::TooLarge)?;
    // Every block's opening randomness contributes to the B-side mask, since
    // each block commitment carries its own rho * Z_H(tau) term.
    let openings_sum = witness
        .openings()
        .iter()
        .fold(Scalar::zero(), |sum, opening| sum + opening.scalar());
    let b_mask = Polynomial::from_coefficients(vec![openings_sum]).ok_or(Error::TooLarge)?;
    let z_a_masked = domain.mask(&z_a,&a_mask)?;
    let z_b_masked = domain.mask(&z_b,&b_mask)?;

    stage!(masking_ns);
    let quotient = match quotient_method {
        QuotientMethod::Generic => {
            let numerator = z_a_masked.multiply(&z_a_masked)? - &z_b_masked;
            let (mut quotient, remainder) = domain.divide(&numerator)?;
            quotient.trim();
            if remainder != Polynomial::zero() {
                return Err(Error::Unsatisfied);
            }
            quotient
        }
        QuotientMethod::Square => if let Some(prepared)=prepared {
            expand_masks(prepared.quotient(&z_a,&z_b)?,&z_a,&a_mask,&b_mask,domain.size())?
        } else { masked_quotient(&z_a, &z_b, &a_mask, &b_mask, domain.size())? },
    };

    stage!(quotient_ns);
    let committed_end = relation
        .committed_start()
        .checked_add(relation.committed_inputs())
        .ok_or(Error::TooLarge)?;
    let ordinary_values = &values[committed_end..];
    if ordinary_values.len() != proving_key.sigma_witness.len()
        || quotient.coefficients().len() > proving_key.sigma_quotient.len()
    {
        return Err(Error::RelationMismatch);
    }
    let t = msm(&proving_key.sigma_witness, ordinary_values)?
        + &msm(
            &[
                proving_key.sigma_mask_constant,
                proving_key.sigma_mask_linear,
            ],
            &[eta_1, eta_2],
        )?
        + &msm(
            &proving_key.sigma_quotient[..quotient.coefficients().len()],
            quotient.coefficients(),
        )?;
    if t == G1::zero() {
        return Err(Error::IdentityPoint { kind: "proof T" });
    }

    stage!(commitment_msm_ns);
    let challenge = if bind_claim {
        transcript_challenge(transcript, &domain, &proving_key.verifying_key, claim, &t)
    } else {
        transcript_challenge_prebound(transcript, &domain, &proving_key.verifying_key, &t)
    };
    let mut z_a_at_challenge = z_a_masked.eval(&challenge);
    let v_a = z_a_at_challenge.clone() - &x_a.eval(&challenge);
    z_a_at_challenge.square();
    let v_r = z_a_at_challenge - &x_b.eval(&challenge);

    let a_opening_numerator = z_a_masked
        - &x_a
        - &Polynomial::from_coefficients(vec![v_a.clone()]).ok_or(Error::TooLarge)?;
    let (mut a_opening, a_remainder) = a_opening_numerator.divide_by_linear(&challenge);
    a_opening.trim();
    if a_remainder != Scalar::zero() {
        return Err(Error::InconsistentOpening);
    }

    let vanishing_quotient = domain.multiply_vanishing(&quotient)?;
    let r_polynomial = z_b_masked - &x_b + &vanishing_quotient;
    let r_opening_numerator =
        r_polynomial - &Polynomial::from_coefficients(vec![v_r]).ok_or(Error::TooLarge)?;
    let (mut r_opening, r_remainder) = r_opening_numerator.divide_by_linear(&challenge);
    r_opening.trim();
    if r_remainder != Scalar::zero() {
        return Err(Error::InconsistentOpening);
    }

    if a_opening.coefficients().len() > proving_key.sigma_a.len()
        || r_opening.coefficients().len() > proving_key.sigma_r.len()
    {
        return Err(Error::RelationMismatch);
    }
    stage!(opening_polynomials_ns);
    let u = msm(
        &proving_key.sigma_a[..a_opening.coefficients().len()],
        a_opening.coefficients(),
    )? + &msm(
        &proving_key.sigma_r[..r_opening.coefficients().len()],
        r_opening.coefficients(),
    )?;
    if u == G1::zero() {
        return Err(Error::IdentityPoint { kind: "proof U" });
    }

    stage!(opening_msm_ns);
    Ok(Proof { t, u, v_a })
}

fn validate_inputs(
    proving_key: &ProvingKey,
    relation: &Relation,
    claim: &Claim,
    witness: &Witness,
    strategy: &impl Strategy,
) -> Result<(), Error> {
    let verifying_key = &proving_key.verifying_key;
    if verifying_key.relation_digest != *relation.digest()
        || proving_key
            .commitment_keys
            .iter()
            .any(|key| key.relation_digest != *relation.digest())
        || verifying_key.commitment_key_digest
            != super::types::commitment_keys_digest(&proving_key.commitment_keys)
        || verifying_key.domain_size as usize != relation.size()
        || verifying_key.public_inputs as usize != relation.public_inputs()
        || verifying_key.blocks.len() != relation.blocks().len()
        || verifying_key
            .blocks
            .iter()
            .zip(relation.blocks())
            .any(|(&size, &expected)| size as usize != expected)
        || witness.assignment().relation_digest() != relation.digest()
    {
        return Err(Error::RelationMismatch);
    }
    if claim.public_inputs.len() != relation.public_inputs() {
        return Err(Error::PublicInputCount {
            expected: relation.public_inputs(),
            actual: claim.public_inputs.len(),
        });
    }
    // Whether the assignment satisfies the relation is checked by the
    // divisibility of the masked constraint polynomial during proving.
    if witness.assignment().values().len() != relation.size() {
        return Err(Error::RelationMismatch);
    }
    if witness.claim(&proving_key.commitment_keys, strategy)? != *claim {
        return Err(Error::ClaimMismatch);
    }
    Ok(())
}

fn evaluate_relation(relation: &Relation, values: &[Scalar]) -> (Vec<Scalar>, Vec<Scalar>) {
    let mut a = vec![Scalar::zero(); relation.size()];
    let mut b = vec![Scalar::zero(); relation.size()];
    for (row, entries) in relation.rows().iter().enumerate() {
        a[row] = dot(&entries.squared, values);
        b[row] = dot(&entries.linear, values);
    }
    (a, b)
}

fn evaluate_public(relation: &Relation, public: &[Scalar]) -> (Vec<Scalar>, Vec<Scalar>) {
    let mut a = vec![Scalar::zero(); relation.size()];
    let mut b = vec![Scalar::zero(); relation.size()];
    for (row, entries) in relation.rows().iter().enumerate() {
        a[row] = dot_public(&entries.squared, public);
        b[row] = dot_public(&entries.linear, public);
    }
    (a, b)
}

/// Dot the public prefix of a sparse row with the public assignment. Row
/// entries are sorted by column, so the public columns form a prefix.
fn dot_public(entries: &[(u32, Scalar)], public: &[Scalar]) -> Scalar {
    entries
        .iter()
        .take_while(|(column, _)| (*column as usize) < public.len())
        .fold(Scalar::zero(), |sum, (column, coefficient)| {
            sum + &(coefficient.clone() * &public[*column as usize])
        })
}
/// Public-column and coset preparation bound to one checked relation.
pub struct PreparedPolynomials {
    digest: [u8;32],
    fft: PreparedTransform,
    domain: Domain,
    a: Vec<Polynomial>,
    b: Vec<Polynomial>,
    powers: Vec<Scalar>,
    inverse_powers: Vec<Scalar>,
    vanishing_inverse: Vec<Scalar>,
}
impl PreparedPolynomials {
    pub fn new(relation: &Relation) -> Result<Self,Error> {
        let domain=Domain::new(relation.size())?;
        let fft=PreparedTransform::new(domain.fft_size())?;
        let width=relation.public_inputs()+1;
        let mut a=vec![vec![Scalar::zero();domain.size()];width];
        let mut b=a.clone();
        for (i,row) in relation.rows().iter().enumerate() {
            for (column,c) in &row.squared { if (*column as usize)<width {a[*column as usize][i]+=c;} }
            for (column,c) in &row.linear { if (*column as usize)<width {b[*column as usize][i]+=c;} }
        }
        let interpolate=|values:Vec<Vec<Scalar>>|->Result<Vec<Polynomial>,Error>{
            values.iter().map(|column| {
                if column.iter().all(|v|*v==Scalar::zero()){return Ok(Polynomial::zero());}
                Polynomial::from_coefficients(domain.interpolate_with(column, |values| fft.interpolate(values))?).ok_or(Error::TooLarge)
            }).collect()
        };
        let a=interpolate(a)?;let b=interpolate(b)?;
        let shift=Scalar::coset_shift();let inverse=shift.inv();
        let vanishing_inverse=domain.coset_inverse(&shift)?;
        let mut powers=Vec::with_capacity(domain.fft_size());let mut inverse_powers=Vec::with_capacity(domain.fft_size());
        let(mut p,mut q)=(Scalar::one(),Scalar::one());
        for _ in 0..domain.fft_size(){powers.push(p.clone());inverse_powers.push(q.clone());p*=&shift;q*=&inverse;}
        Ok(Self{digest:*relation.digest(),fft,domain,a,b,powers,inverse_powers,vanishing_inverse})
    }
    fn polynomial(&self, values: &[Scalar]) -> Result<Polynomial, Error> {
        Polynomial::from_coefficients(self.domain.interpolate_with(values, |weighted| self.fft.interpolate(weighted))?).ok_or(Error::TooLarge)
    }
    fn public(&self,relation:&Relation,values:&[Scalar])->Result<(Polynomial,Polynomial),Error>{
        if self.digest!=*relation.digest() || self.domain.size()!=relation.size() || values.len()!=self.a.len(){return Err(Error::RelationMismatch);}
        let combine=|columns:&[Polynomial]|->Result<Polynomial,Error>{
            let mut coefficients=vec![Scalar::zero();self.domain.size()];
            for (column,value) in columns.iter().zip(values){for (out,c) in coefficients.iter_mut().zip(column.coefficients()){*out+=&(c.clone()*value);}}
            let mut polynomial=Polynomial::from_coefficients(coefficients).ok_or(Error::TooLarge)?;polynomial.trim();Ok(polynomial)
        };
        Ok((combine(&self.a)?,combine(&self.b)?))
    }
    fn quotient(&self,a:&Polynomial,b:&Polynomial)->Result<Polynomial,Error>{
        if a.coefficients().len()>self.domain.size() || b.coefficients().len()>self.domain.size(){return Err(Error::RelationMismatch);}
        let shifted=|polynomial:&Polynomial| polynomial.coefficients().iter().zip(&self.powers).map(|(c,p)|c.clone()*p).collect::<Vec<_>>();
        let mut evaluated=self.fft.evaluate(&shifted(a))?;let other=self.fft.evaluate(&shifted(b))?;
        for (i,(x,y)) in evaluated.iter_mut().zip(other).enumerate(){x.square();*x-= &y;*x*=&self.vanishing_inverse[i%self.vanishing_inverse.len()];}
        let mut coefficients=self.fft.interpolate(&evaluated)?;
        for (c,p) in coefficients.iter_mut().zip(&self.inverse_powers){*c*=p;}
        if coefficients[self.domain.size()-1..].iter().any(|c|*c!=Scalar::zero()){return Err(Error::Unsatisfied);}
        coefficients.truncate(self.domain.size()-1);
        Polynomial::from_coefficients(coefficients).ok_or(Error::TooLarge)
    }
}

/// Ordinary statement binding with relation-bound public polynomials and checked coset division.
pub fn prove_with_prepared_msm(
    rng:&mut impl CryptoRng, transcript:&mut Transcript, proving_key:&ProvingKey,
    relation:&Relation, claim:&Claim, witness:&Witness, strategy:&impl Strategy,
    prepared:&PreparedPolynomials, msm:&mut dyn FnMut(&[G1],&[Scalar])->Result<G1,Error>,
)->Result<Proof,Error>{
    prove_inner(rng,transcript,proving_key,relation,claim,witness,strategy,true,QuotientMethod::Square,Some(prepared),None,msm)
}

pub struct ReferencePolynomials {
    digest: [u8;32],
    domain: FftDomain<Scalar>,
    a: Vec<Polynomial>,
    b: Vec<Polynomial>,
    powers: Vec<Scalar>,
    inverse_powers: Vec<Scalar>,
    vanishing_inverse: Scalar,
}
impl ReferencePolynomials {
    pub fn new(relation: &Relation) -> Result<Self,Error> {
        let domain=FftDomain::new(relation.size().next_power_of_two())?;
        let width=relation.public_inputs()+1;
        let mut a=vec![vec![Scalar::zero();domain.size()];width];
        let mut b=a.clone();
        for (i,row) in relation.rows().iter().enumerate() {
            for (column,c) in &row.squared { if (*column as usize)<width {a[*column as usize][i]+=c;} }
            for (column,c) in &row.linear { if (*column as usize)<width {b[*column as usize][i]+=c;} }
        }
        let interpolate=|values:Vec<Vec<Scalar>>|->Result<Vec<Polynomial>,Error>{
            values.iter().map(|column| {
                if column.iter().all(|v|*v==Scalar::zero()){return Ok(Polynomial::zero());}
                Ok(Polynomial::interpolate(&domain,column)?)
            }).collect()
        };
        let a=interpolate(a)?;let b=interpolate(b)?;
        let shift=Scalar::coset_shift();let inverse=shift.inv();
        let vanishing=domain.evaluate_vanishing(&shift);
        if vanishing==Scalar::zero(){return Err(Error::RelationMismatch);}
        let mut powers=Vec::with_capacity(domain.size());let mut inverse_powers=Vec::with_capacity(domain.size());
        let(mut p,mut q)=(Scalar::one(),Scalar::one());
        for _ in 0..domain.size(){powers.push(p.clone());inverse_powers.push(q.clone());p*=&shift;q*=&inverse;}
        Ok(Self{digest:*relation.digest(),domain,a,b,powers,inverse_powers,vanishing_inverse:vanishing.inv()})
    }
    fn public(&self,relation:&Relation,values:&[Scalar])->Result<(Polynomial,Polynomial),Error>{
        if self.digest!=*relation.digest() || self.domain.size()!=relation.size().next_power_of_two() || values.len()!=self.a.len(){return Err(Error::RelationMismatch);}
        let combine=|columns:&[Polynomial]|->Result<Polynomial,Error>{
            let mut coefficients=vec![Scalar::zero();self.domain.size()];
            for (column,value) in columns.iter().zip(values){for (out,c) in coefficients.iter_mut().zip(column.coefficients()){*out+=&(c.clone()*value);}}
            let mut polynomial=Polynomial::from_coefficients(coefficients).ok_or(Error::TooLarge)?;polynomial.trim();Ok(polynomial)
        };
        Ok((combine(&self.a)?,combine(&self.b)?))
    }
    fn quotient(&self,a:&Polynomial,b:&Polynomial)->Result<Polynomial,Error>{
        if a.coefficients().len()>self.domain.size() || b.coefficients().len()>self.domain.size(){return Err(Error::RelationMismatch);}
        let shifted=|polynomial:&Polynomial| polynomial.coefficients().iter().zip(&self.powers).map(|(c,p)|c.clone()*p).collect::<Vec<_>>();
        let mut evaluated=self.domain.evaluate(&shifted(a))?;let other=self.domain.evaluate(&shifted(b))?;
        for (x,y) in evaluated.iter_mut().zip(other){x.square();*x-= &y;*x*=&self.vanishing_inverse;}
        let mut coefficients=self.domain.interpolate(&evaluated)?;
        for (c,p) in coefficients.iter_mut().zip(&self.inverse_powers){*c*=p;}
        Polynomial::from_coefficients(coefficients).ok_or(Error::TooLarge)
    }
}


fn expand_reference_masks(base:Polynomial,a:&Polynomial,mask_a:&Polynomial,mask_b:&Polynomial,size:usize)->Result<Polynomial,Error>{
    let [constant, linear] = mask_a.coefficients() else {
        return Err(Error::RelationMismatch);
    };
    let mut cross = vec![Scalar::zero(); a.coefficients().len() + 1];
    for (i, value) in a.coefficients().iter().enumerate() {
        cross[i] += &(value.clone() * &(constant.clone() + constant));
        cross[i + 1] += &(value.clone() * &(linear.clone() + linear));
    }
    let cross = Polynomial::from_coefficients(cross).ok_or(Error::TooLarge)?;
    let mask_square = mask_a.multiply(mask_a)?.mul_vanishing(size)?;
    let mut quotient = base + &cross + &mask_square - mask_b;
    quotient.trim();
    Ok(quotient)
}

pub struct PolynomialScreen {
    subset: PreparedPolynomials,
    reference: ReferencePolynomials,
    pub subset_preparation_ns: u128,
    pub reference_preparation_ns: u128,
}
pub struct ScreenOutput {
    pub quotient: Polynomial,
    pub a_opening: Polynomial,
    pub r_opening: Polynomial,
    a_masked: Polynomial,
    b_masked: Polynomial,
}
impl PolynomialScreen {
    pub fn new(relation:&Relation)->Result<Self,Error>{
        let start=std::time::Instant::now();let subset=PreparedPolynomials::new(relation)?;let subset_preparation_ns=start.elapsed().as_nanos();
        let start=std::time::Instant::now();let reference=ReferencePolynomials::new(relation)?;let reference_preparation_ns=start.elapsed().as_nanos();
        Ok(Self{subset,reference,subset_preparation_ns,reference_preparation_ns})
    }
    pub fn work(&self,relation:&Relation,witness:&Witness,subset:bool,eta:[Scalar;2],challenge:&Scalar)->Result<ScreenOutput,Error>{
        if witness.assignment().relation_digest()!=relation.digest(){return Err(Error::RelationMismatch)}
        let values=witness.assignment().values();
        if values.len()!=relation.size(){return Err(Error::RelationMismatch)}
        let n=if subset{relation.size()}else{relation.size().next_power_of_two()};
        let mut ae=vec![Scalar::zero();n];let mut be=ae.clone();
        for (i,row) in relation.rows().iter().enumerate(){ae[i]=dot(&row.squared,values);be[i]=dot(&row.linear,values);}
        if ae.iter().zip(&be).any(|(a,b)|a.clone()*a!=*b){return Err(Error::Unsatisfied)}
        let public=witness.assignment().public_assignment();
        let (a,b,xa,xb)=if subset{
            let d=&self.subset.domain;let (xa,xb)=self.subset.public(relation,public)?;
            (d.polynomial(&ae)?,d.polynomial(&be)?,xa,xb)
        }else{
            let d=&self.reference.domain;let (xa,xb)=self.reference.public(relation,public)?;
            (Polynomial::interpolate(d,&ae)?,Polynomial::interpolate(d,&be)?,xa,xb)
        };
        let am=Polynomial::from_coefficients(eta.to_vec()).ok_or(Error::TooLarge)?;
        let bm=Polynomial::from_coefficients(vec![witness.openings().iter().fold(Scalar::zero(),|sum,o|sum+o.scalar())]).ok_or(Error::TooLarge)?;
        let (a_masked,b_masked,quotient)=if subset{
            let d=&self.subset.domain;
            (d.mask(&a,&am)?,d.mask(&b,&bm)?,expand_masks(self.subset.quotient(&a,&b)?,&a,&am,&bm,n)?)
        }else{
            (a.mask_vanishing(&am,n)?,b.mask_vanishing(&bm,n)?,expand_reference_masks(self.reference.quotient(&a,&b)?,&a,&am,&bm,n)?)
        };
        let mut av=a_masked.eval(challenge);let va=av.clone()-&xa.eval(challenge);av.square();let vr=av-&xb.eval(challenge);
        let an=a_masked.clone()-&xa-&Polynomial::from_coefficients(vec![va]).ok_or(Error::TooLarge)?;
        let (mut a_opening,ar)=an.divide_by_linear(challenge);a_opening.trim();if ar!=Scalar::zero(){return Err(Error::InconsistentOpening)}
        let qz=if subset{self.subset.domain.multiply_vanishing(&quotient)?}else{quotient.mul_vanishing(n)?};
        let rn=b_masked.clone()-&xb+&qz-&Polynomial::from_coefficients(vec![vr]).ok_or(Error::TooLarge)?;
        let (mut r_opening,rr)=rn.divide_by_linear(challenge);r_opening.trim();if rr!=Scalar::zero(){return Err(Error::InconsistentOpening)}
        Ok(ScreenOutput{quotient,a_opening,r_opening,a_masked,b_masked})
    }
    pub fn validate(&self,relation:&Relation,witness:&Witness,eta:[Scalar;2],challenge:&Scalar)->Result<(),Error>{
        if !relation.check_witness(witness){return Err(Error::Unsatisfied)}
        for subset in [false,true]{
            let result=self.work(relation,witness,subset,eta.clone(),challenge)?;
            let product=result.a_masked.multiply(&result.a_masked)?-&result.b_masked;
            let (mut q,r)=if subset{self.subset.domain.divide(&product)?}else{product.divide_by_vanishing(self.reference.domain.size())?};
            q.trim();if r!=Polynomial::zero() || q!=result.quotient{return Err(Error::Unsatisfied)}
            let (mut a,mut b)=evaluate_public(relation,witness.assignment().public_assignment());
            let (expected_a,expected_b,xa,xb)=if subset{
                let (xa,xb)=self.subset.public(relation,witness.assignment().public_assignment())?;
                (self.subset.domain.polynomial(&a)?,self.subset.domain.polynomial(&b)?,xa,xb)
            }else{
                let d=&self.reference.domain;a.resize(d.size(),Scalar::zero());b.resize(d.size(),Scalar::zero());
                let (xa,xb)=self.reference.public(relation,witness.assignment().public_assignment())?;
                (Polynomial::interpolate(d,&a)?,Polynomial::interpolate(d,&b)?,xa,xb)
            };
            let normalize=|mut p:Polynomial|{p.trim();p};
            if normalize(expected_a)!=normalize(xa) || normalize(expected_b)!=normalize(xb){return Err(Error::RelationMismatch)}
        }
        Ok(())
    }
}
