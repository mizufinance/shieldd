/**
 * Test (multi-threaded) Wasm MSM for consistency against bigint implementation.
 *
 * This test currently doesn't use node:test so that we can run it in the browser.
 */
import {
  Weierstraß,
  TwistedEdwards,
  startThreads,
  stopThreads,
} from "./parallel.ts";
import { pallasParams, vestaParams } from "./concrete/pasta.params.ts";
import { curveParams as bls12377Params } from "./concrete/bls12-377.params.ts";
import { curveParams as bls12381Params } from "./concrete/bls12-381.params.ts";
import { curveParams as edBls12Params } from "./concrete/ed-on-bls12-377.params.ts";
import { ed25519Params } from "./concrete/ed25519.params.ts";
import { bn254Params } from "./concrete/bn254.params.ts";
import { secp256k1Params } from "./concrete/secp256k1.params.ts";
import { assert } from "./util.ts";
import { type CurveParams } from "./bigint/affine-weierstrass.ts";
import { type CurveParams as TwistedEdwardsParams } from "./bigint/twisted-edwards.ts";
import { assertDeepEqual } from "./testing/nested.ts";

let nThreads = 16;
await startThreads(nThreads);

// twisted edwards curves
await testMsmTE(edBls12Params);
await testMsmTE(ed25519Params);

// weierstrass curves with a=0 and endomorphism
await testMsm(pallasParams);
await testMsm(vestaParams);
await testMsm(bls12377Params);
await testMsm(bls12381Params);
await testMsm(bn254Params);
await testMsm(secp256k1Params);

await stopThreads();

async function testMsm(curveParams: CurveParams) {
  console.log("testing msm", curveParams.label);
  const Curve = await Weierstraß.create(curveParams);

  for (let n = 0; n < 14; n += 2) {
    await testOneMsm(Curve, n);
  }
}

async function testOneMsm(Curve: Weierstraß, n: number) {
  const { Field, Affine, Projective, Scalar, Parallel, Bigint } = Curve;
  let N = 1 << n;
  using _ = Field.local.atCurrentOffset;
  let scratch = Field.local.getPointers(5);

  let pointsPtrs = await Parallel.randomPointsFast(N);
  let scalarPtrs = await Parallel.randomScalars(N);

  let points = pointsPtrs.map((g) => {
    assert(Affine.isOnCurve(scratch, g), "point not on curve");
    return Bigint.Projective.fromAffine(Affine.toBigint(g));
  });

  let scalars = scalarPtrs.map((s) => {
    let scalar = Scalar.readBigint(s);
    assert(scalar < Scalar.modulus);
    return scalar;
  });
  assert(scalars.length === N);

  let { result } = await Parallel.msmUnsafe(scalarPtrs[0], pointsPtrs[0], N);
  let s = Projective.toBigint(result);

  let sBigint = Bigint.Projective.msm(scalars, points);

  assert(Bigint.Projective.isEqual(s, sBigint), `msm 2^${n} failed`);

  // projective msm
  let { result: resultProjective } = await Parallel.msmProjective(
    scalarPtrs[0],
    pointsPtrs[0],
    N
  );
  let sProjective = Projective.toBigint(resultProjective);
  assert(
    Bigint.Projective.isEqual(s, sProjective),
    `msmProjective 2^${n} failed`
  );
}

async function testMsmTE(curveParams: TwistedEdwardsParams) {
  console.log("testing msm", curveParams.label);
  const Curve = await TwistedEdwards.create(curveParams);

  for (let n = 0; n < 14; n += 2) {
    await testOneMsmTE(Curve, n);
  }
}

async function testOneMsmTE(C: TwistedEdwards, n: number) {
  const { Field, Curve, Scalar, Parallel, Bigint } = C;
  let N = 1 << n;
  using _ = Field.local.atCurrentOffset;
  let scratch = Field.local.getPointers(5);

  let pointsPtrs = await Parallel.randomPointsFast(N);
  let scalarPtrs = await Parallel.randomScalars(N);

  let points = pointsPtrs.map((g) => {
    assert(Curve.isOnCurve(scratch, g), "point not on curve");
    return Curve.toBigint(g);
  });

  let scalars = scalarPtrs.map((s) => {
    let scalar = Scalar.toBigint(s);
    assert(scalar < Scalar.modulus);
    return scalar;
  });
  assert(scalars.length === N);

  let { result } = await Parallel.msm(scalarPtrs[0], pointsPtrs[0], N);
  let s = Bigint.toAffine(Curve.toBigint(result));
  let sBigint = Bigint.toAffine(Bigint.msm(scalars, points));
  assertDeepEqual(s, sBigint, `msm 2^${n} failed`);
}
