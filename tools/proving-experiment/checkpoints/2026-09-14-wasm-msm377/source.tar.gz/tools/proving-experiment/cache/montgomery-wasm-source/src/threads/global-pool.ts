import { ThreadPool, barrier, expose, isMain } from "./threads.ts";

export { pool, setWorkerSource, broadcastFromMain };

let pool = ThreadPool.createInactive(import.meta.url);

function setWorkerSource(source: string) {
  pool.setSource(source);
}

// message passing

async function broadcastFromMain<T>(
  namespace: string,
  func: () => T
): Promise<T> {
  let name = `broadcast:${namespace}`;
  let promise = new Promise<T>((resolve) => {
    expose(name, function f(m: T) {
      resolve(m);
    });
  });
  let message = isMain() ? func() : undefined;
  // barrier so all workers are ready to receive
  await barrier();
  if (isMain()) {
    await pool.callWorkers(`${name};f`, message);
    return message!;
  } else {
    return promise;
  }
}
