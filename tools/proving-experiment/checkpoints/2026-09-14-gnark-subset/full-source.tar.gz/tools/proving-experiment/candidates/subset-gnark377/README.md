# gnark Groth16 subset-domain experiment

Development-only fair control for the selected-DH Transfer circuit. The first gate measures the actual pinned gnark coset-N quotient against checked M196608/N262144 subset arithmetic. Only the quotient commitment query shrinks; wire-indexed queries remain unchanged. This component screen does not establish a new Groth16 proof or full-API result.

`prepare.py` copies pinned gnark v0.15.0 and the exact selected-DH module into a fresh ignored cache, adds the local experiment sources and records hashes. Production modules and frozen workers remain unchanged. Build/run sequentially under the parent resource guard with GOTOOLCHAIN=go1.25.7 and GOMAXPROCS=2.
